package com.example.dreamdream

import com.example.dreamdream.functions.NukeSSLCerts

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {
    var queue : RequestQueue? = null
    var stringText = ""
    var stringText2 = ""
    var id = ""
    var pw = ""
    var name = ""
    var gender = ""
    var email = ""
    var phone = ""
    var grant = ""
    var rentalOne = ""
    var rentalTwo = ""


    lateinit var edittextId : EditText
    lateinit var editTextPw : EditText
    lateinit var btnLogin : Button
    lateinit var btnSignup : Button
    lateinit var btnFindId : Button
    lateinit var btnFindPw : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        NukeSSLCerts.nuke();

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        if(queue == null){
            queue = Volley.newRequestQueue(this)
        }

        // xml id값 가져오기
        edittextId = findViewById(R.id.login_id)
        editTextPw = findViewById(R.id.login_pw)
        btnLogin = findViewById(R.id.login_join)
        btnSignup= findViewById(R.id.login_signup)
        btnFindId = findViewById(R.id.login_findid)
        btnFindPw = findViewById(R.id.login_findPw)

        // 버튼마다 클릭 이벤트 부착(서버 통신)
        btnLogin.setOnClickListener{
            // url
            val url = "https://203.250.133.144:8080/user-join/" + edittextId.text + "/" + editTextPw.text
            // 통신 확인
            testVolley(url)
            // url
            val url2 = "https://203.250.133.144:8080/user-info/" + edittextId.text + "/" + editTextPw.text
            // 통신 확인
            getInfoVolley(url2)
            // url
            val url3 = "https://203.250.133.144:8080/manager-rental-check/1"
            // 통신 확인
            rentalCheckVolley1(url3)
            // url
            val url4 = "https://203.250.133.144:8080/manager-rental-check/2"
            // 통신 확인
            rentalCheckVolley2(url4)

            // 로그인 가능(관리자)
            if(stringText.contains("관리자")){
                // 관리자 페이지로 들어가는 코드
                println("관리자")
                val intent = Intent(this, subactivity_user::class.java)
                intent.putExtra("u1", rentalOne.toString())
                intent.putExtra("u2", rentalTwo.toString())
                val person = Person(id,pw,name,email,phone,grant)
                intent.putExtra("person",person)

                startActivity(intent)
            }
            // 로그인 가능(사용자)
            else if(stringText.contains("사용자")) {
                // 사용자 페이지로 들어가는 코드
                println("사용자")
                val intent = Intent(this, subactivity_user::class.java)
                intent.putExtra("u1", rentalOne.toString())
                intent.putExtra("u2", rentalTwo.toString())
                val person = Person(id,pw,name,email,phone,grant)
                intent.putExtra("person",person)
                println("rentalOne : $rentalOne | rentalTwo : $rentalTwo")
                startActivity(intent)
            }
            // 로그인 불가
            else{
                println("로그인 불가 : $stringText")
                Toast.makeText(this@MainActivity, "로그인 실패", Toast.LENGTH_SHORT).show()
            }
        }

        // 회원가입으로 화면 전환
        btnSignup.setOnClickListener{
            val nextIntent = Intent(this, subactivity_singup::class.java)
            startActivity(nextIntent)
        }
        btnFindId.setOnClickListener{
            val nextIntent = Intent(this, subactivity_findid::class.java)
            startActivity(nextIntent)
        }
        btnFindPw.setOnClickListener{
            val nextIntent = Intent(this, subactivity_findpw::class.java)
            startActivity(nextIntent)
        }
    }

    // 인텐트 정보를 저장하는 클래스 생성
    class Person constructor(val id: String, val pw: String, val name: String, val email : String, val phone : String, val grant : String) : Parcelable
    {
        constructor(parcel: Parcel) : this(
            parcel.readString().toString(),
            parcel.readString().toString(),
            parcel.readString().toString(),
            parcel.readString().toString(),
            parcel.readString().toString(),
            parcel.readString().toString()
        ) {
        }

        override fun writeToParcel(parcel: Parcel, flags: Int) {
            parcel.writeString(id)
            parcel.writeString(pw)
            parcel.writeString(name)
            parcel.writeString(email)
            parcel.writeString(phone)
            parcel.writeString(grant)
        }

        override fun describeContents(): Int {
            return 0
        }

        companion object CREATOR : Parcelable.Creator<Person> {
            override fun createFromParcel(parcel: Parcel): Person {
                return Person(parcel)
            }

            override fun newArray(size: Int): Array<Person?> {
                return arrayOfNulls(size)
            }
        }
    }

    private fun testVolley(url : String) {
        val myJson = JSONObject()
        val requestBody = myJson.toString()
        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
            // 한글 깨짐 방지
            stringText = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            stringText = removeDot(stringText)
        }, Response.ErrorListener { error ->
            stringText = "error : $error"
        })
        {}
        // url 호출 등록
        queue?.add(testRequest)
    }

    private fun getInfoVolley(url : String) {
        val myJson = JSONObject()
        val requestBody = myJson.toString()
        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
            // 한글 깨짐 방지
            stringText2 = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            var str_arr = stringText2.split(",")

            // 데이터 정제
            id = removeDot(str_arr[0])
            id = id.replace("[","")
            id = id.replace("\n","")
            id = id.replace(" ","")
            id = removeDot(id)

            pw = removeDot(str_arr[1])
            pw = pw.replace("\n","")
            pw = pw.replace(" ","")
            pw = removeDot(pw)

            name = removeDot(str_arr[2])
            name = name.replace("\n","")
            name = name.replace(" ","")
            name = removeDot(name)

            gender = removeDot(str_arr[3])
            gender = gender.replace("\n","")
            gender = gender.replace(" ","")
            gender = removeDot(gender)

            email = removeDot(str_arr[4])
            email = email.replace("\n","")
            email = email.replace(" ","")
            email = removeDot(email)

            phone = removeDot(str_arr[5])
            phone = phone.replace("\n","")
            phone = phone.replace(" ","")
            phone = removeDot(phone)

            grant = removeDot(str_arr[6])
            grant = grant.replace("]","")
            grant = grant.replace("\n","")
            grant = grant.replace(" ","")
            grant = removeDot(grant)
        }, Response.ErrorListener { error ->
            stringText2 = "error : $error"
        })
        {}
        // url 호출 등록
        queue?.add(testRequest)
    }

    private fun rentalCheckVolley1(url : String) {
        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
            // 한글 깨짐 방지
            rentalOne = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            rentalOne = removeDot(rentalOne)
        }, Response.ErrorListener { error ->
            rentalOne = "error : $error"
        })
        {}
        // url 호출 등록
        queue?.add(testRequest)
    }
    private fun rentalCheckVolley2(url : String) {
        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
            // 한글 깨짐 방지
            rentalTwo = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            rentalTwo = removeDot(rentalTwo)
        }, Response.ErrorListener { error ->
            rentalTwo = "error : $error"
        })
        {}
        // url 호출 등록
        queue?.add(testRequest)
    }

    fun removeDot( str : String ) : String {
        val re = "^\"|\"$".toRegex()
        return str.replace(re, "")
    }
}

//class VolleyServiceGet constructor(url: String){
//    val url = url
//
//    fun testVolley(context: Context, success: (Boolean) -> Unit) {
//
////        val myJson = JSONObject("{ " +
////                "'user_id' : 'ckwjdwns', " +
////                "'user_pw' : 'hahahahaha', " +
//////                "'user_name' : '차정준', " +
//////                "'user_gender' : '남자', " +
//////                "'user_email' : 'ckwjdwns@naver.com', " +
//////                "'user_phone' : '010-0000-1234' " +
////                "}")
//        val myJson = JSONObject()
//        val requestBody = myJson.toString()
//        /* myJson에 아무 데이터도 put 하지 않았기 때문에 requestBody는 "{}" 이다 */
//
//        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
//            println("서버 Response 수신: $response")
//            success(true)
//        }, Response.ErrorListener { error ->
//            Log.d("ERROR", "서버 Response 가져오기 실패: $error")
//            success(false)
//        }) {
//            override fun getBodyContentType(): String {
//                return "application/json; charset=utf-8"
//            }
//
//            override fun getBody(): ByteArray {
//                return requestBody.toByteArray()
//            }
//            /* getBodyContextType에서는 요청에 포함할 데이터 형식을 지정한다.
//             * getBody에서는 요청에 JSON이나 String이 아닌 ByteArray가 필요하므로, 타입을 변경한다. */
//        }
//
//        Volley.newRequestQueue(context).add(testRequest)
//    }
//
//}
//object VolleyService {
//
//    val testUrl = "https://203.250.133.144:8080/user_join_membership"
//
//    fun testVolley(context: Context, success: (Boolean) -> Unit) {
//
//        val myJson = JSONObject("{ " +
//                "'user_id' : 'ckwjdwns', " +
//                "'user_pw' : 'hahahahaha', " +
//                "'user_name' : '차정준', " +
//                "'user_gender' : '남자', " +
//                "'user_email' : 'ckwjdwns@naver.com', " +
//                "'user_phone' : '010-0000-1234' " +
//                "}")
//        val requestBody = myJson.toString()
//        /* myJson에 아무 데이터도 put 하지 않았기 때문에 requestBody는 "{}" 이다 */
//
//        val testRequest = object : StringRequest(Method.POST, testUrl , Response.Listener { response ->
//            println("서버 Response 수신: $response")
//            success(true)
//        }, Response.ErrorListener { error ->
//            Log.d("ERROR", "서버 Response 가져오기 실패: $error")
//            success(false)
//        }) {
//            override fun getBodyContentType(): String {
//                return "application/json; charset=utf-8"
//            }
//
//            override fun getBody(): ByteArray {
//                return requestBody.toByteArray()
//            }
//            /* getBodyContextType에서는 요청에 포함할 데이터 형식을 지정한다.
//             * getBody에서는 요청에 JSON이나 String이 아닌 ByteArray가 필요하므로, 타입을 변경한다. */
//        }
//
//        Volley.newRequestQueue(context).add(testRequest)
//    }
//}