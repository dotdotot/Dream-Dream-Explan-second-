package com.example.dreamdream


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.dreamdream.functions.NukeSSLCerts
import org.json.JSONObject

class subactivity_user : AppCompatActivity()  {
    var queue : RequestQueue? = null
    var stringText = ""
    var pw = ""

    lateinit var textView1 : TextView
    lateinit var textView2 : TextView

    lateinit var imageView1: ImageView
    lateinit var imageView2: ImageView

    lateinit var logoutBtn : Button
    lateinit var rentalBtn1 : Button
    lateinit var rentalBtn2 : Button
    lateinit var returnBtn1 : Button
    lateinit var returnBtn2 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        NukeSSLCerts.nuke()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.subactivity_user)

        if(queue == null){
            queue = Volley.newRequestQueue(this)
        }
        textView1 = findViewById(R.id.user_uTextView1)
        textView2 = findViewById(R.id.user_uTextView2)
        imageView1 = findViewById(R.id.user_imageView1)
        imageView2 = findViewById(R.id.user_imageView2)
        logoutBtn = findViewById(R.id.user_logout)
        rentalBtn1 = findViewById(R.id.user_rentalBtn1)
        rentalBtn2 = findViewById(R.id.user_rentalBtn2)
        returnBtn1 = findViewById(R.id.user_returnBtn1)
        returnBtn2 = findViewById(R.id.user_returnBtn2)
        // 대여 가능, 불가 인텐트에서 가져오기
        textView1.text = intent.getStringExtra("u1")
        textView2.text = intent.getStringExtra("u2")
        println(intent.getStringExtra("u1"))
        println(intent.getStringExtra("u2"))
        // 버튼 비활성화, 활성화
        println("1번 우산 : ${textView1.text}")
        println("2번 우산 : ${textView2.text}")
        if(textView1.text.contains("가능")){
            println("대여가능에 들어왔습니다.")
            // 활성화
            rentalBtn1.isEnabled = true
            // 비활성화
            returnBtn1.isEnabled = false
        }else{
            // 활성화
            rentalBtn1.isEnabled = false
            // 비활성화
            returnBtn1.isEnabled = true
        }

        if(textView2.text.contains("가능")){
            println("대여가능에 들어왔습니다.")
            // 활성화
            rentalBtn2.isEnabled = true
            // 비활성화
            returnBtn2.isEnabled = false
        }else{
            // 활성화
            rentalBtn2.isEnabled = false
            // 비활성화
            returnBtn2.isEnabled = true
        }

        val person = intent.getParcelableExtra<MainActivity.Person>("person")
        if (person != null)  // Null 체크
        {
            println("person : ${person.id} / ${person.pw} / ${person.name} / ${person.email} / " +
                    "${person.phone} / ${person.grant}")
        }

        logoutBtn.setOnClickListener{
            val nextIntent = Intent(this, MainActivity::class.java)
            startActivity(nextIntent)
        }

        rentalBtn1.setOnClickListener{
            println("rentalBtn1 click")
            // url
            val url = "https://203.250.133.144:8080/manager-rental-door/1"
            // 통신 확인
            if (person != null) {
                rentalVolley(url, person)
            }
        }

        rentalBtn2.setOnClickListener{
            println("rentalBtn2 click")
            // url
            val url = "https://203.250.133.144:8080/manager-rental-door/2"
            // 통신 확인
            if (person != null) {
                rentalVolley(url, person)
            }
        }

        returnBtn1.setOnClickListener{
            println("returnBtn1 click")
            // url
            val url = "https://203.250.133.144:8080/manager-return-door/1"
            // 통신 확인
            if (person != null) {
                rentalVolley(url, person)
            }
        }

        returnBtn2.setOnClickListener{
            println("returnBtn2 click")
            // url
            val url = "https://203.250.133.144:8080/manager-return-door/2"
            // 통신 확인
            if (person != null) {
                rentalVolley(url, person)
            }
        }
    }

    private fun testVolley(url : String) {
        val myJson = JSONObject()
        val requestBody = myJson.toString()
        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
            // 한글 깨짐 방지
            stringText = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            stringText = removeDot(stringText)
        }, Response.ErrorListener { error ->
            stringText = "error : $error"
        })
        {}
        // url 호출 등록
        queue?.add(testRequest)
    }

    private fun rentalVolley(url : String, person : MainActivity.Person) {
        val myJson = JSONObject("{" + "'user_id' : '${person.id}'" + "}")
        val requestBody = myJson.toString()

        val testRequest = object : StringRequest(Method.POST, url , Response.Listener { response ->
            // 한글 깨짐 방지
            stringText = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            stringText = removeDot(stringText)
        }, Response.ErrorListener { error ->
            stringText = "error : $error"
        })
        {
            override fun getBodyContentType(): String {
                return "application/json; charset=utf-8"
            }

            override fun getBody(): ByteArray {
                return requestBody.toByteArray()
            }
        }
        // url 호출 등록
        queue?.add(testRequest)
    }

    fun removeDot( str : String ) : String {
        val re = "^\"|\"$".toRegex()
        return str.replace(re, "")
    }
}