package com.example.dreamdream

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.dreamdream.functions.NukeSSLCerts
import org.json.JSONObject

class subactivity_singup : AppCompatActivity() {
    var queue : RequestQueue? = null
    var stringText = ""
    var radioText = ""

    lateinit var idEditText : EditText
    lateinit var pwEditText : EditText
    lateinit var checkPwEditText : EditText
    lateinit var nameEditText : EditText
    lateinit var emailEditText : EditText
    lateinit var phoneEditText : EditText


    lateinit var radioGroup: RadioGroup
    lateinit var menRadioButton: RadioButton
    lateinit var womenRadioButton : RadioButton

    lateinit var okBtn : Button
    lateinit var cancelBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        NukeSSLCerts.nuke();

        super.onCreate(savedInstanceState)
        setContentView(R.layout.subactivity_singup)

        if(queue == null){
            queue = Volley.newRequestQueue(this)
        }

        // 고유 id값 가져오기
        idEditText = findViewById(R.id.signup_id)
        pwEditText = findViewById(R.id.signup_pw)
        checkPwEditText = findViewById(R.id.signup_checkPw)
        nameEditText = findViewById(R.id.signup_name)
        emailEditText = findViewById(R.id.signup_email)
        phoneEditText = findViewById(R.id.signup_phone)

        radioGroup = findViewById(R.id.signup_radio)
        menRadioButton = findViewById(R.id.signup_men)
        womenRadioButton = findViewById(R.id.signup_women)

        okBtn = findViewById(R.id.signup_okBtn)
        cancelBtn = findViewById(R.id.signup_cancelBtn)

        // 라디오 버튼 이벤트 부착
        radioGroup.setOnCheckedChangeListener(CheckboxListener())

        // 회원가입 이벤트 부착
        okBtn.setOnClickListener{
            // url
            val url = "https://203.250.133.144:8080/user-join-membership"

            // 통신 확인
            testVolley(url)
            val nextIntent = Intent(this, MainActivity::class.java)
            startActivity(nextIntent)
        }
        // 취소 이벤트 부착
        cancelBtn.setOnClickListener{
            val nextIntent = Intent(this, MainActivity::class.java)
            startActivity(nextIntent)
        }
    }

    // 라디오 그룹의 버튼을 누를때마다 텍스트가 바뀌도록 하는 내부 클래스
    inner class CheckboxListener : RadioGroup.OnCheckedChangeListener{
        override fun onCheckedChanged(group: RadioGroup?, checkedId: Int) {
            when (group?.id){
                R.id.signup_radio ->
                    when(checkedId){
                        R.id.signup_men -> radioText = "남자"
                        R.id.signup_women -> radioText = "여자"
                    }
            }
            // Logcat확인용
            println("버튼 : $radioText")
        }
    }

    private fun testVolley(url : String) {
        val myJson = JSONObject("{ " +
                "'user_id' : '${idEditText.text}', " +
                "'user_pw' : '${pwEditText.text}', " +
                "'user_name' : '${nameEditText.text}', " +
                "'user_gender' : '${radioText}', " +
                "'user_email' : '${emailEditText.text}', " +
                "'user_phone' : '${phoneEditText.text}' " +
                "}")
        val requestBody = myJson.toString()

        val testRequest = object : StringRequest(Method.POST, url , Response.Listener { response ->
            // 한글 깨짐 방지
            stringText = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            stringText = removeDot(stringText)
        }, Response.ErrorListener { error ->
            stringText = "error : $error"
            Toast.makeText(this@subactivity_singup, "회원가입 실패", Toast.LENGTH_SHORT).show()
        })
        {
            override fun getBodyContentType(): String {
                return "application/json; charset=utf-8"
            }

            override fun getBody(): ByteArray {
                return requestBody.toByteArray()
            }
        }
        // url 호출 등록
        queue?.add(testRequest)
    }

    fun removeDot( str : String ) : String {
        val re = "^\"|\"$".toRegex()
        return str.replace(re, "")
    }
}