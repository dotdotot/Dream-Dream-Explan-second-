package com.example.dreamdream

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.dreamdream.functions.NukeSSLCerts
import org.json.JSONObject

class subactivity_findid  : AppCompatActivity()  {
    var queue : RequestQueue? = null
    var stringText = ""
    lateinit var nameEditText : EditText
    lateinit var emailEditText : EditText
    lateinit var phoneEditText : EditText
    lateinit var backBtn : Button
    lateinit var findidBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        NukeSSLCerts.nuke();

        super.onCreate(savedInstanceState)
        setContentView(R.layout.subactivity_findid)

        if(queue == null){
            queue = Volley.newRequestQueue(this)
        }

        // xml id값 가져오기
        nameEditText = findViewById(R.id.findid_name)
        emailEditText = findViewById(R.id.findid_email)
        phoneEditText = findViewById(R.id.findid_phone)
        backBtn = findViewById(R.id.findid_back)
        findidBtn = findViewById(R.id.findid_findidBtn)

        backBtn.setOnClickListener{
            val nextIntent = Intent(this, MainActivity::class.java)
            startActivity(nextIntent)
        }
        findidBtn.setOnClickListener(ButtonListenerFindId())
    }

    // 아이디 찾기 버튼 이벤트 정의
    inner class ButtonListenerFindId : View.OnClickListener{
        override fun onClick(v : View?){
            // url
            val url = "https://203.250.133.144:8080/user-id-find/" + nameEditText.text + "/" + emailEditText.text + "/" + phoneEditText.text

            // 통신 확인
            testVolley(url)

            // ==, equal 왜 안될까?
                    // 로그인 가능(관리자)
                    if(stringText.contains("false")){
                Toast.makeText(this@subactivity_findid, "아이디 찾기 실패", Toast.LENGTH_SHORT).show()
            }else{
                val builder = AlertDialog.Builder(this@subactivity_findid)
                builder
                    .setTitle("아이디 찾기")
                    .setMessage("아이디 : $stringText")
                    .setPositiveButton("확인",
                        DialogInterface.OnClickListener { dialog, id ->
                            // Start 버튼 선택시 수행
                        })
                builder.create()
                builder.show()
            }
        }
    }

    private fun testVolley(url : String) {
        val myJson = JSONObject()
        val requestBody = myJson.toString()
        val testRequest = object : StringRequest(Method.GET, url , Response.Listener { response ->
            // 한글 깨짐 방지
            stringText = String(response.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
            stringText = removeDot(stringText)
        }, Response.ErrorListener { error ->
            stringText = "error : $error"
        })
        {}

        // url 호출 등록
        queue?.add(testRequest)
    }
    fun removeDot( str : String ) : String {
        val re = "^\"|\"$".toRegex()
        return str.replace(re, "")
    }

}